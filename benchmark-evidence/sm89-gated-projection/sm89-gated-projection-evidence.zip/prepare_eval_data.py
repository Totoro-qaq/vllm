"""Fetch the two frozen public GSM8K files, checking hashes before use."""

import argparse
import hashlib
import json
from pathlib import Path
import urllib.request


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--data-dir", type=Path, default=Path(__file__).parent / "eval-data"
    )
    args = parser.parse_args()
    manifest = json.loads((args.data_dir / "manifest.json").read_text())
    for name in ["train", "test"]:
        entry = manifest[name]
        path = args.data_dir / f"{name}.jsonl"
        raw = (
            path.read_bytes()
            if path.exists()
            else urllib.request.urlopen(entry["url"], timeout=60).read()
        )
        assert hashlib.sha256(raw).hexdigest() == entry["sha256"], name
        assert len(raw.splitlines()) == entry["rows"], name
        if not path.exists():
            temporary = path.with_suffix(".tmp")
            temporary.write_bytes(raw)
            temporary.replace(path)
        print(
            json.dumps(
                {"file": str(path), "rows": entry["rows"], "sha256": entry["sha256"]}
            )
        )


if __name__ == "__main__":
    main()
