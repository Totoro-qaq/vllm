"""Paired full GSM8K evaluation with per-question evidence and active-kernel proof."""

import argparse
import ast
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time
import traceback
import uuid

from http_measure import json_request, measure, token_hash
from run_study import build_command, runtime_preflight

ROOT = Path(__file__).resolve().parent


def answer_value(text):
    numbers = re.findall(r"\d+", text.replace(",", ""))
    if not numbers:
        return -9999999
    try:
        return ast.literal_eval(numbers[-1])
    except SyntaxError:
        return -9999999


def build_prompts(root):
    manifest = json.loads((root / "manifest.json").read_text())
    data = {}
    for split in ["train", "test"]:
        raw = (root / (split + ".jsonl")).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == manifest[split]["sha256"]
        data[split] = [json.loads(line) for line in raw.splitlines() if line.strip()]
    assert len(data["test"]) == 1319
    few = "".join(
        f"Question: {x['question']}\nAnswer: {x['answer']}\n\n"
        for x in data["train"][:5]
    )
    rows = [
        {
            "index": i,
            "prompt": few + f"Question: {x['question']}\nAnswer:",
            "label": answer_value(x["answer"]),
        }
        for i, x in enumerate(data["test"])
    ]
    assert all(row["label"] != -9999999 for row in rows)
    return rows, manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--capture", type=Path, required=True)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--runtime-lock", type=Path, default=ROOT / "runtime-main-b2.json"
    )
    parser.add_argument("--port", type=int, default=29794)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    args.batch_tokens = None
    args.output = args.output.resolve()
    rows, manifest = build_prompts(args.data)
    protocol = json.loads((ROOT / "final_eval_protocol.json").read_text())
    command = build_command(args) + [
        "--worker-extension-cls",
        "integrated_rpc.IntegratedWorker",
    ]
    command += [
        "--compilation-config",
        json.dumps({"mode": 0, "custom_ops": ["all", "+gated_linear_silu"]}),
    ]
    if not args.execute:
        print(
            json.dumps(
                {
                    "gpu_executed": False,
                    "questions": len(rows),
                    "protocol": protocol,
                    "command": command,
                }
            )
        )
        return 0
    args.output.mkdir(parents=True, exist_ok=False)
    state = {
        "status": "preflight",
        "protocol": protocol,
        "manifest": manifest,
        "timings": [],
        "evaluations": {},
        "command": command,
    }
    server = server_log = None
    prepared = False
    began = time.monotonic()
    tokens = json.loads((ROOT / "prompt.json").read_text())["ids"]
    assert len(tokens) == 16384

    def save():
        state["elapsed_s"] = time.monotonic() - began
        p = args.output / "run.tmp"
        p.write_text(json.dumps(state, indent=2, allow_nan=False) + "\n")
        p.replace(args.output / "run.json")

    def rpc(method, *rpc_args):
        response = json_request(
            args.port,
            "POST",
            "/collective_rpc",
            {"method": method, "args": list(rpc_args), "timeout": 180},
        )
        assert len(response["results"]) == 1
        return response["results"][0]

    def reset():
        assert json_request(args.port, "POST", "/reset_prefix_cache")["success"]

    def timed(mode, label, ids=tokens):
        rpc("mlp_set_mode", mode)
        reset()
        r = measure(args.port, ids, "eval-timing-" + uuid.uuid4().hex)
        state["timings"].append(
            {
                "mode": mode,
                "label": label,
                "length": len(ids),
                **r,
                "dispatch": rpc("mlp_stats"),
            }
        )
        save()

    def question(row, mode):
        start = time.monotonic()
        response = json_request(
            args.port,
            "POST",
            "/v1/completions",
            {
                "model": "prefill-study",
                "prompt": row["prompt"],
                "temperature": 0,
                "seed": 42,
                "max_tokens": 256,
                "stop": protocol["stop"],
                "cache_salt": "gsm-"
                + mode
                + "-"
                + str(row["index"])
                + "-"
                + uuid.uuid4().hex,
                "return_token_ids": True,
            },
            timeout=600,
        )
        choice = response["choices"][0]
        usage = response["usage"]
        assert usage["completion_tokens"] >= 0
        assert usage["prompt_tokens_details"]["cached_tokens"] == 0
        return {
            "index": row["index"],
            "label": row["label"],
            "prediction": answer_value(choice["text"]),
            "prompt_text_sha256": hashlib.sha256(row["prompt"].encode()).hexdigest(),
            "prompt_token_sha256": token_hash(choice["prompt_token_ids"]),
            "response": response,
            "elapsed_s": time.monotonic() - start,
        }

    def evaluate(mode, label, selected):
        rpc("mlp_set_mode", mode)
        reset()
        stamp = time.monotonic()
        records = []
        log = args.output / (label + ".jsonl")
        with (
            log.open("w") as file,
            ThreadPoolExecutor(max_workers=protocol["concurrency"]) as pool,
        ):
            futures = {
                pool.submit(question, row, mode): row["index"] for row in selected
            }
            try:
                for future in as_completed(futures):
                    record = future.result()
                    records.append(record)
                    file.write(json.dumps(record, allow_nan=False) + "\n")
                    file.flush()
                    if len(records) % 64 == 0:
                        state["evaluation_progress"] = {
                            "label": label,
                            "done": len(records),
                            "total": len(selected),
                        }
                        save()
                        print(json.dumps(state["evaluation_progress"]), flush=True)
            except Exception:
                for future in futures:
                    future.cancel()
                raise
        assert len(records) == len(selected)
        stats = rpc("mlp_stats")
        if mode == "virtual":
            assert (
                sum(v for k, v in stats["calls"].items() if k.startswith("candidate:"))
                > 0
            ), "Evaluation never exercised candidate"
        result = {
            "questions": len(records),
            "correct": sum(r["prediction"] == r["label"] for r in records),
            "invalid": sum(r["prediction"] == -9999999 for r in records),
            "empty": sum(
                not r["response"]["choices"][0]["text"].strip() for r in records
            ),
            "elapsed_s": time.monotonic() - stamp,
            "dispatch": stats,
            "records_file": log.name,
        }
        result["accuracy"] = result["correct"] / len(records)
        state["evaluations"][label] = result
        save()
        return records

    try:
        lock = json.loads(args.runtime_lock.read_text())
        state["runtime"] = runtime_preflight(args, lock)
        env = {k: v for k, v in os.environ.items() if not k.startswith("VLLM_")}
        env.update(
            PYTHONPATH=str(ROOT),
            VLLM_SERVER_DEV_MODE="1",
            VLLM_NO_USAGE_STATS="1",
            HF_HUB_OFFLINE="1",
            TRANSFORMERS_OFFLINE="1",
            OMP_NUM_THREADS="1",
            VLLM_GPU_SYNC_CHECK="error",
        )
        server_log = (args.output / "server.log").open("w")
        server = subprocess.Popen(
            command,
            cwd=args.output,
            env=env,
            stdout=server_log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        start = time.monotonic()
        state["status"] = "starting_server"
        save()
        while True:
            if server.poll() is not None:
                raise RuntimeError("Server exited at startup")
            try:
                json_request(args.port, "GET", "/health", timeout=2)
                break
            except (OSError, ValueError, RuntimeError):
                if time.monotonic() - start > 600:
                    raise TimeoutError("Startup timeout")
                time.sleep(1)
        state["effective_vllm_config"] = json_request(
            args.port, "GET", "/server_info?config_format=json"
        )["vllm_config"]
        effective = state["effective_vllm_config"]
        assert effective["compilation_config"]["mode"] == 0
        assert effective["compilation_config"]["cudagraph_mode"] == [2, 1]
        assert effective["scheduler_config"]["max_num_batched_tokens"] == 2048
        assert effective["cache_config"]["gpu_memory_utilization"] == 0.85
        assert effective["cache_config"]["block_size"] == 528
        for _ in range(3):
            reset()
            measure(args.port, tokens, "eval-base-" + uuid.uuid4().hex)
        state["preparation"] = rpc(
            "mlp_prepare",
            "[64,64,32,4,3]",
            str(args.capture / "inputs/activations-layer0.pt"),
        )
        prepared = True
        state["sync_check"] = rpc("mlp_sync_info")
        assert state["sync_check"] == {"mode": "error", "enabled": True}
        state["status"] = "sync_check_requests"
        for length in [528, 16384]:
            for mode in ["original", "virtual"]:
                timed(mode, f"sync_{length}", tokens[:length])
        state["status"] = "complete"
        state["restored"] = rpc("mlp_remove")
        prepared = False
    except Exception as exc:
        state["status"] = "failed"
        state["error"] = repr(exc)
        (args.output / "traceback.log").write_text(traceback.format_exc())
    finally:
        if prepared and server is not None and server.poll() is None:
            try:
                state["cleanup_restored"] = rpc("mlp_remove")
            except Exception as exc:
                state["cleanup_error"] = repr(exc)
        if server is not None:
            try:
                os.killpg(server.pid, signal.SIGTERM)
                server.wait(timeout=30)
            except ProcessLookupError:
                pass
            except subprocess.TimeoutExpired:
                os.killpg(server.pid, signal.SIGKILL)
                server.wait(timeout=10)
            state["owned_server_exit_code"] = server.returncode
        if server_log:
            server_log.close()
        save()
    print(
        json.dumps(
            {
                "status": state["status"],
                "error": state.get("error"),
                "primary_reduction_pct": state.get("primary_reduction_pct"),
            }
        ),
        flush=True,
    )
    return 0 if state["status"] in ["complete", "stopped_limited_performance"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
