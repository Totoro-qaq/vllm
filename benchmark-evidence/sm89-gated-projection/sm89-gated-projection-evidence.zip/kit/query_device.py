"""Short-lived device query; invoked only during explicit GPU execution."""

import ctypes
import json


def main():
    import torch

    props = torch.cuda.get_device_properties(0)
    cuda = ctypes.CDLL("libcuda.so.1")
    device, l2 = ctypes.c_int(), ctypes.c_int()
    if cuda.cuInit(0) or cuda.cuDeviceGet(ctypes.byref(device), 0):
        raise RuntimeError("CUDA device query failed")
    if cuda.cuDeviceGetAttribute(ctypes.byref(l2), 38, device):
        raise RuntimeError("CUDA L2 metadata query failed")
    print(
        json.dumps(
            {
                "name": props.name,
                "sm": list(torch.cuda.get_device_capability(0)),
                "device_count": torch.cuda.device_count(),
                "multiprocessors": props.multi_processor_count,
                "memory_bytes": props.total_memory,
                "l2_bytes": l2.value,
                "torch_cuda": torch.version.cuda,
            }
        )
    )


if __name__ == "__main__":
    main()
