"""Prepare or run one warmed HTTP prefill study using vLLM's public profiler API."""

import argparse
import hashlib
from importlib import metadata
import json
import os
from pathlib import Path
import signal
import socket
import statistics
import subprocess
import sys
import time
import traceback
import uuid

from http_measure import json_request, measure, token_hash
from trace_report import analyze_directory

ROOT = Path(__file__).resolve().parent


def build_command(args):
    profiler = {
        "profiler": "torch",
        "torch_profiler_dir": str(args.output / "traces"),
        "torch_profiler_with_stack": False,
        "torch_profiler_with_flops": False,
        "torch_profiler_record_shapes": False,
        "torch_profiler_with_memory": False,
        "torch_profiler_use_gzip": True,
        "ignore_frontend": True,
    }
    command = [
        sys.executable,
        "-m",
        "vllm.entrypoints.cli.main",
        "serve",
        str(args.model_dir),
        "--served-model-name",
        "prefill-study",
        "--host",
        "127.0.0.1",
        "--port",
        str(args.port),
        "--max-model-len",
        "16576",
        "--dtype",
        "bfloat16",
        "--language-model-only",
        "--gpu-memory-utilization",
        "0.85",
        "--seed",
        "20261103",
        "--enable-prompt-tokens-details",
        "--profiler-config",
        json.dumps(profiler),
    ]
    if args.batch_tokens is not None:
        command += ["--max-num-batched-tokens", str(args.batch_tokens)]
    return command


def check_source(repo, lock):
    head = subprocess.check_output(
        ["git", "-C", str(repo), "rev-parse", "HEAD"], text=True
    ).strip()
    if head != lock["head"]:
        raise ValueError("Source head differs from runtime lock")
    changes = subprocess.check_output(
        ["git", "-C", str(repo), "status", "--porcelain", "--untracked-files=no"],
        text=True,
    )
    if changes.strip():
        raise ValueError("Tracked source changes must be isolated and pinned first")
    paths = [
        "vllm/engine/arg_utils.py",
        "vllm/config/profiler.py",
        "vllm/model_executor/layers/mamba/gdn/qwen_gdn_linear_attn.py",
        "vllm/entrypoints/serve/profile/api_router.py",
        "vllm/entrypoints/openai/completion/protocol.py",
        "vllm/entrypoints/openai/completion/serving.py",
    ]
    return {
        "head": head,
        "files": {
            path: hashlib.sha256((repo / path).read_bytes()).hexdigest()
            for path in paths
        },
    }


def check_installed_sources(repo, lock):
    """Keep the official wheel unchanged and verify it against the pinned tree."""
    if lock.get("layout", "source-tree") != "installed-wheel":
        return None
    expected = check_source(repo, lock)["files"]
    distribution = metadata.distribution("vllm")
    records = {}
    for name, digest in expected.items():
        installed = distribution.locate_file(name).resolve()
        if hashlib.sha256(installed.read_bytes()).hexdigest() != digest:
            raise ValueError("Installed wheel source differs from checkout: " + name)
        records[name] = {"path": str(installed), "sha256": digest}
    return records


def runtime_preflight(args, lock):
    if sys.platform != "linux":
        raise ValueError("GPU execution requires the prepared Linux environment")
    packages = {name: metadata.version(name) for name in lock["packages"]}
    if packages != lock["packages"]:
        raise ValueError(f"Package versions differ from runtime lock: {packages}")
    installed_sources = check_installed_sources(args.repo, lock)
    model = json.loads((ROOT / "model-lock.json").read_text())
    for name, expected in model["files"].items():
        path = args.model_dir / name
        if not path.is_file() or path.stat().st_size != expected["bytes"]:
            raise ValueError("Missing or wrong model file: " + name)
        with path.open("rb") as stream:
            if hashlib.file_digest(stream, "sha256").hexdigest() != expected["sha256"]:
                raise ValueError("Model hash mismatch: " + name)
    active = subprocess.check_output(
        ["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"], text=True
    )
    if active.strip():
        raise ValueError("Another GPU compute process is active")
    # Let a short-lived process release its CUDA context before launching vLLM.
    probe = subprocess.run(
        [sys.executable, str(ROOT / "query_device.py")],
        check=True,
        text=True,
        capture_output=True,
        timeout=60,
    )
    gpu = json.loads(probe.stdout)
    if gpu["device_count"] != 1 or gpu["sm"] != lock["sm"]:
        raise ValueError("GPU capability/count differs from runtime lock")
    if lock.get("torch_cuda") is not None and gpu["torch_cuda"] != lock["torch_cuda"]:
        raise ValueError("Torch CUDA build differs from runtime lock")
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", args.port))
    return {
        "packages": packages,
        "installed_sources": installed_sources,
        "model": model,
        "gpu": gpu,
        "driver": subprocess.check_output(
            ["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"],
            text=True,
        ).strip(),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--runtime-lock", type=Path, default=ROOT / "runtime-sm89.json")
    parser.add_argument("--batch-tokens", type=int, default=None)
    parser.add_argument("--port", type=int, default=29793)
    parser.add_argument("--startup-timeout", type=int, default=900)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    args.repo, args.model_dir, args.output = (
        path.resolve() for path in (args.repo, args.model_dir, args.output)
    )
    if args.batch_tokens is not None and args.batch_tokens < 256:
        parser.error(
            "This study retains default max_num_seqs; token budget must be >=256"
        )
    if args.startup_timeout <= 0 or not 1024 <= args.port <= 65535:
        parser.error("Invalid startup timeout or port")
    lock = json.loads(args.runtime_lock.read_text())
    source = check_source(args.repo, lock)
    prompt = json.loads((ROOT / "prompt.json").read_text())
    tokens = prompt["ids"]
    if len(tokens) != 16384 or token_hash(tokens) != prompt["sha256"]:
        raise ValueError("Frozen prompt changed")
    command = build_command(args)
    plan = {
        "source": source,
        "runtime_lock": lock,
        "command": command,
        "warmups": 3,
        "unprofiled_repetitions": 5,
        "profiled_requests": 1,
        "post_profile_control_requests": 1,
        "prompt_sha256": prompt["sha256"],
        "output_tokens": 1,
        "concurrency": 1,
        "batch_token_override": args.batch_tokens,
        "defaults_preserved": [
            "graph mode",
            "attention backend",
            "GDN backend",
            "cache block sizes",
            "max_num_seqs",
            "async scheduling",
            "prefix-cache enablement",
        ],
        "explicit_workload_controls": [
            "text only",
            "BF16",
            "max_model_len=16576",
            "gpu_memory_utilization=0.85",
            "zero cache hits",
        ],
        "gpu_executed": False,
    }
    if not args.execute:
        print(json.dumps(plan, indent=2))
        return 0
    args.output.mkdir(parents=True, exist_ok=False)
    state = {"status": "preflight", "plan": plan, "requests": []}
    server = None
    server_log = None
    profiled = False

    def save():
        temporary = args.output / "run.tmp"
        temporary.write_text(json.dumps(state, indent=2, allow_nan=False) + "\n")
        temporary.replace(args.output / "run.json")

    def request(label, reset=True):
        if reset:
            result = json_request(args.port, "POST", "/reset_prefix_cache")
            if not isinstance(result, dict) or result.get("success") is not True:
                raise RuntimeError("Prefix-cache reset did not succeed")
        value = measure(args.port, tokens, "prefill-study-" + uuid.uuid4().hex)
        state["requests"].append({"label": label, **value})
        save()
        return value

    try:
        state["runtime"] = runtime_preflight(args, lock)
        state["plan"]["gpu_executed"] = True
        env = dict(os.environ)
        # Do not inherit the earlier BI/eager/forced-backend experimental setup.
        for key in list(env):
            if key.startswith("VLLM_"):
                env.pop(key)
        env.update(
            {
                "VLLM_SERVER_DEV_MODE": "1",
                "VLLM_NO_USAGE_STATS": "1",
                "HF_HUB_OFFLINE": "1",
                "TRANSFORMERS_OFFLINE": "1",
                "OMP_NUM_THREADS": "1",
            }
        )
        wheel_layout = lock.get("layout", "source-tree") == "installed-wheel"
        if wheel_layout:
            env.pop("PYTHONPATH", None)
        else:
            env["PYTHONPATH"] = str(args.repo)
        state["environment_overrides"] = {
            key: env.get(key)
            for key in [
                "PYTHONPATH",
                "VLLM_SERVER_DEV_MODE",
                "VLLM_NO_USAGE_STATS",
                "HF_HUB_OFFLINE",
                "TRANSFORMERS_OFFLINE",
                "OMP_NUM_THREADS",
            ]
        }
        state["status"] = "starting_server"
        save()
        server_log = (args.output / "server.log").open("w")
        start = time.monotonic()
        server = subprocess.Popen(
            command,
            cwd=args.output if wheel_layout else args.repo,
            env=env,
            stdout=server_log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        while True:
            if server.poll() is not None:
                raise RuntimeError(f"Server exited during startup: {server.returncode}")
            try:
                json_request(args.port, "GET", "/health", timeout=2)
                break
            except (OSError, RuntimeError, ValueError):
                if time.monotonic() - start > args.startup_timeout:
                    raise TimeoutError("Server startup timeout; inspect server.log")
                time.sleep(1)
        state["startup_seconds"] = time.monotonic() - start
        info = json_request(args.port, "GET", "/server_info?config_format=json")
        state["effective_vllm_config"] = info["vllm_config"]
        state["status"] = "warmup"
        save()
        for index in range(3):
            request(f"warmup_{index}")
        state["status"] = "unprofiled_timing"
        for index in range(5):
            request(f"steady_{index}")
        measured = [
            row for row in state["requests"] if row["label"].startswith("steady_")
        ]
        values = [row["ttft_s"] for row in measured]
        state["steady_ttft"] = {
            "samples_s": values,
            "median_s": statistics.median(values),
            "min_s": min(values),
            "max_s": max(values),
            "profiler_configured_but_inactive": True,
        }
        state["status"] = "profiling"
        save()
        reset = json_request(args.port, "POST", "/reset_prefix_cache")
        if not isinstance(reset, dict) or reset.get("success") is not True:
            raise RuntimeError("Prefix-cache reset before profiling failed")
        json_request(args.port, "POST", "/start_profile")
        profiled = True
        request("profile_diagnostic", reset=False)
        json_request(args.port, "POST", "/stop_profile", timeout=300)
        profiled = False
        request("post_profile_control")
        state["trace"] = analyze_directory(args.output / "traces")
        steps = state["trace"]["worker"]["steps"]
        state["trace_context_tokens"] = (
            sum(step["context_tokens"] for step in steps) if steps else None
        )
        state["trace_context_tokens_verified"] = state["trace_context_tokens"] == len(
            tokens
        )
        outputs = [row["token_ids"] for row in state["requests"]]
        state["all_first_tokens_equal"] = all(value == outputs[0] for value in outputs)
        state["status"] = (
            "complete"
            if state["trace_context_tokens_verified"]
            else "complete_missing_step_attribution"
        )
        state["classification_requires_review"] = True
    except Exception as exc:
        state["status"] = "failed"
        state["error"] = repr(exc)
        (args.output / "traceback.log").write_text(traceback.format_exc())
    finally:
        if profiled:
            try:
                json_request(args.port, "POST", "/stop_profile", timeout=300)
            except Exception as exc:
                state["profile_cleanup_error"] = repr(exc)
        if server is not None:
            try:
                os.killpg(server.pid, signal.SIGTERM)
                server.wait(timeout=30)
            except ProcessLookupError:
                pass
            except subprocess.TimeoutExpired:
                os.killpg(server.pid, signal.SIGKILL)
                server.wait(timeout=10)
            state["owned_server_exit_code"] = server.returncode
        if server_log is not None:
            server_log.close()
        save()
    print(
        json.dumps(
            {
                "status": state["status"],
                "output": str(args.output),
                "steady_ttft": state.get("steady_ttft"),
            }
        )
    )
    return 0 if state["status"].startswith("complete") else 1


if __name__ == "__main__":
    raise SystemExit(main())
