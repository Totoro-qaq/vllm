"""Observe and control the installed integration without replacing forward methods."""

import hashlib
from importlib import metadata
from pathlib import Path


class IntegratedWorker:
    def mlp_sync_info(self):
        from vllm.utils import gpu_sync_debug

        return {
            "mode": gpu_sync_debug._SYNC_CHECK_MODE,
            "enabled": gpu_sync_debug._sync_check_enabled,
        }

    def mlp_prepare(self, _config_json, _activation_file):
        import torch

        from vllm.model_executor.layers.fusion.gated_linear_silu import GatedLinearSilu

        model = self.get_model()
        assert not hasattr(model, "_integrated_mlp_control")
        assert int(self.vllm_config.compilation_config.mode) == 0
        assert self.vllm_config.compilation_config.max_cudagraph_capture_size == 512
        layers = [
            (module, module.gate_up_silu)
            for name, module in model.named_modules()
            if name.endswith(".mlp")
            and isinstance(getattr(module, "gate_up_silu", None), GatedLinearSilu)
        ]
        assert len(layers) == 32, (
            f"Expected real integration in 32 layers, got {len(layers)}"
        )
        state = {"layers": layers, "mode": "virtual", "calls": {}}
        first = layers[0][0]

        def observe(_module, args):
            x = args[0]
            weight = first.gate_up_proj.weight
            if (
                x.ndim == 2
                and 768 <= x.shape[0] <= 4096
                and x.dtype == weight.dtype == torch.bfloat16
                and x.is_contiguous()
                and weight.is_contiguous()
            ):
                key = (
                    "candidate:" if first.gate_up_silu is not None else "native:"
                ) + str(x.shape[0])
                state["calls"][key] = state["calls"].get(key, 0) + 1

        state["hook"] = first.register_forward_pre_hook(observe)
        model._integrated_mlp_control = state
        dist = metadata.distribution("vllm")
        paths = [
            "vllm/model_executor/models/qwen2_moe.py",
            "vllm/model_executor/layers/fusion/gated_linear_silu.py",
            "vllm/kernels/triton/gated_linear_silu.py",
        ]
        return {
            "enabled_layers": len(layers),
            "persistent_weight_copy_bytes": 0,
            "control": "Toggle the actual Qwen2MoeMLP.gate_up_silu child between None and its original operation; forward methods are untouched.",
            "observer": "First MLP pre-hook only; count eligible row steps, not inferred calls across all layers. Captured small-row paths are excluded.",
            "installed_sources": {
                name: hashlib.sha256(
                    Path(dist.locate_file(name)).read_bytes()
                ).hexdigest()
                for name in paths
            },
        }

    def mlp_set_mode(self, mode):
        import torch

        assert mode in ("original", "virtual")
        torch.cuda.synchronize()
        state = self.get_model()._integrated_mlp_control
        for module, op in state["layers"]:
            module.gate_up_silu = op if mode == "virtual" else None
        state["mode"] = mode
        state["calls"].clear()
        torch.cuda.reset_peak_memory_stats()
        return {"mode": mode}

    def mlp_stats(self):
        import torch

        torch.cuda.synchronize()
        state = self.get_model()._integrated_mlp_control
        return {
            "mode": state["mode"],
            "calls": state["calls"],
            "counter_scope": "one representative MLP layer",
            "allocated_bytes": torch.cuda.memory_allocated(),
            "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
        }

    def mlp_remove(self):
        model = self.get_model()
        if hasattr(model, "_integrated_mlp_control"):
            self.mlp_set_mode("virtual")
            model._integrated_mlp_control["hook"].remove()
            delattr(model, "_integrated_mlp_control")
        return {
            "restored": not hasattr(model, "_integrated_mlp_control"),
            "mode": "default_enabled",
        }
