"""HTTP timing and strict streaming-response checks; no vLLM or torch imports."""

import hashlib
import http.client
import json
import time


def token_hash(ids):
    return hashlib.sha256(json.dumps(ids, separators=(",", ":")).encode()).hexdigest()


class ResponseCollector:
    """A prompt-only or empty SSE event is not a generated first token."""

    def __init__(self, expected_prompt):
        self.expected_prompt = expected_prompt
        self.ids = []
        self.first_token_s = None
        self.usage = None
        self.finish_reason = None
        self.done = False
        self.prompt_verified = False

    def feed(self, data, elapsed):
        if data == "[DONE]":
            self.done = True
            return
        event = json.loads(data)
        if event.get("error"):
            raise ValueError(event["error"])
        if event.get("usage") is not None:
            self.usage = event["usage"]
        for choice in event.get("choices", []):
            if choice.get("index") != 0:
                raise ValueError("Expected a single response choice")
            prompt = choice.get("prompt_token_ids")
            if prompt is not None:
                if prompt != self.expected_prompt:
                    raise ValueError("Server changed the tokenized prompt")
                self.prompt_verified = True
            ids = choice.get("token_ids") or []
            if ids:
                if any(type(token) is not int for token in ids):
                    raise ValueError("Invalid generated token IDs")
                if self.first_token_s is None:
                    self.first_token_s = elapsed
                self.ids.extend(ids)
            if choice.get("finish_reason") is not None:
                self.finish_reason = choice["finish_reason"]

    def finish(self, total_s):
        if not self.done or not self.prompt_verified:
            raise ValueError("Missing DONE or prompt identity evidence")
        if (
            len(self.ids) != 1
            or self.first_token_s is None
            or self.finish_reason != "length"
        ):
            raise ValueError("Expected exactly one generated token ending at the limit")
        if not self.usage or self.usage.get("prompt_tokens") != len(
            self.expected_prompt
        ):
            raise ValueError("Prompt usage mismatch")
        if self.usage.get("completion_tokens") != 1:
            raise ValueError("Completion usage mismatch")
        cached = (self.usage.get("prompt_tokens_details") or {}).get("cached_tokens")
        if type(cached) is not int or cached != 0:
            raise ValueError("Expected explicit zero prefix-cache hits")
        return {
            "ttft_s": self.first_token_s,
            "total_s": total_s,
            "token_ids": self.ids,
            "finish_reason": self.finish_reason,
            "usage": self.usage,
            "prompt_sha256": token_hash(self.expected_prompt),
            "scope": "localhost HTTP time to first generated token ID; one output token",
        }


def json_request(port, method, path, payload=None, timeout=180):
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=timeout)
    try:
        body = json.dumps(payload).encode() if payload is not None else None
        connection.request(
            method, path, body=body, headers={"Content-Type": "application/json"}
        )
        response = connection.getresponse()
        raw = response.read()
        if response.status != 200:
            raise RuntimeError(f"{path}: HTTP {response.status}: {raw[:1000]!r}")
        return json.loads(raw) if raw.strip() else None
    finally:
        connection.close()


def measure(port, tokens, salt, timeout=180):
    body = json.dumps(
        {
            "model": "prefill-study",
            "prompt": tokens,
            "max_tokens": 1,
            "temperature": 0,
            "seed": 20261103,
            "ignore_eos": True,
            "add_special_tokens": False,
            "return_token_ids": True,
            "stream": True,
            "stream_options": {"include_usage": True},
            "cache_salt": salt,
        }
    ).encode()
    collector = ResponseCollector(tokens)
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=timeout)
    start = time.perf_counter()
    try:
        connection.request(
            "POST",
            "/v1/completions",
            body=body,
            headers={"Content-Type": "application/json"},
        )
        response = connection.getresponse()
        if response.status != 200:
            raise RuntimeError(
                f"Completion HTTP {response.status}: {response.read()[:1000]!r}"
            )
        while line := response.readline():
            elapsed = time.perf_counter() - start
            line = line.decode().strip()
            if line.startswith("data: "):
                collector.feed(line[6:], elapsed)
            if collector.done:
                break
        return collector.finish(time.perf_counter() - start)
    finally:
        connection.close()
