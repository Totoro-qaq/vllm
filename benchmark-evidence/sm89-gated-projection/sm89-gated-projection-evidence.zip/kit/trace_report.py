"""Summarize CUDA trace events without summing overlapping CPU/GPU ranges."""

import argparse
from collections import Counter, defaultdict
import gzip
import json
from pathlib import Path
import re


def category(name):
    lower = name.lower()
    if any(
        part in lower
        for part in (
            "gated_delta",
            "gdn",
            "chunk_delta_h",
            "chunk_fwd_kernel_o",
            "chunk_scaled_dot_kkt",
            "solve_tril",
            "inverse_kernel",
            "recompute_w_u",
            "chunk_local_cumsum",
        )
    ):
        return "gdn_chain"
    if any(
        part in lower
        for part in (
            "causal_conv",
            "conv1d",
            "rms_norm",
            "rmsnorm",
            "layer_norm",
            "layernorm",
        )
    ):
        return "convolution_and_normalization"
    if any(
        part in lower
        for part in (
            "flash_fwd",
            "flash::",
            "flashinfer",
            "paged_attention",
            "attention_kernel",
            "unified_attention",
        )
    ):
        return "full_attention"
    if any(part in lower for part in ("gemm", "gemv", "matmul", "cublas", "cutlass")):
        return "gemm"
    return "other_or_unclassified"


def union_duration(intervals):
    total = 0.0
    end = None
    for start, stop in sorted(intervals):
        if end is None or start > end:
            total += stop - start
        elif stop > end:
            total += stop - end
        end = max(stop, end) if end is not None else stop
    return total


def summarize(events):
    kernels, activity = [], []
    annotations = []
    devices = set()
    for event in events:
        if event.get("ph") != "X" or event.get("dur", 0) <= 0:
            continue
        kind = event.get("cat", "").lower()
        name = event.get("name", "")
        if name.startswith("execute_") and kind in ("user_annotation", "cpu_op"):
            annotations.append(
                {"name": name, "ts_us": event["ts"], "dur_us": event["dur"]}
            )
        if kind not in ("kernel", "gpu_kernel", "gpu_memcpy", "gpu_memset"):
            continue
        device = event.get("args", {}).get("device")
        if device is not None:
            devices.add(str(device))
        activity.append((float(event["ts"]), float(event["ts"] + event["dur"])))
        if kind in ("kernel", "gpu_kernel"):
            kernels.append(event)
    if not kernels:
        raise ValueError(
            "No CUDA kernel events; a CPU-only trace cannot establish GPU shares"
        )
    if len(devices) > 1:
        raise ValueError("This analyzer expects one GPU; do not merge device timelines")
    sums, names, counts = defaultdict(float), defaultdict(float), Counter()
    for event in kernels:
        name, duration = event["name"], float(event["dur"])
        sums[category(name)] += duration
        names[name] += duration
        counts[name] += 1
    kernel_sum = sum(sums.values())
    activity_union = union_duration(activity)
    span = max(stop for _, stop in activity) - min(start for start, _ in activity)
    steps = []
    for row in annotations:
        match = re.fullmatch(
            r"execute_context_(\d+)\((\d+)\)_generation_(\d+)\((\d+)\)", row["name"]
        )
        if match:
            context_requests, context_tokens, generation_requests, generation_tokens = (
                map(int, match.groups())
            )
            steps.append(
                {
                    "context_requests": context_requests,
                    "context_tokens": context_tokens,
                    "generation_requests": generation_requests,
                    "generation_tokens": generation_tokens,
                }
            )
    return {
        "scope": "profiled request only; categories inferred from kernel names",
        "kernel_count": len(kernels),
        "sum_kernel_ms": kernel_sum / 1000,
        "categories": {
            name: {
                "sum_ms": duration / 1000,
                "share_of_summed_kernel_time": duration / kernel_sum,
            }
            for name, duration in sorted(sums.items(), key=lambda item: -item[1])
        },
        "gpu_activity_span_ms": span / 1000,
        "gpu_activity_union_ms": activity_union / 1000,
        "gaps_inside_activity_span_ms": (span - activity_union) / 1000,
        "gap_note": "Trace gaps include possible profiler overhead and are not automatically CPU scheduler overhead; excludes request edges.",
        "steps": steps,
        "annotations": annotations,
        "top_kernels": [
            {
                "name": name,
                "category": category(name),
                "sum_ms": duration / 1000,
                "calls": counts[name],
            }
            for name, duration in sorted(names.items(), key=lambda item: -item[1])
        ],
        "not_a_steady_state_ttft_measurement": True,
    }


def analyze_directory(root):
    reports, ignored = [], []
    for path in sorted(Path(root).rglob("*.pt.trace.json*")):
        opener = gzip.open if path.suffix == ".gz" else open
        with opener(path, "rt") as stream:
            data = json.load(stream)
        events = data["traceEvents"] if isinstance(data, dict) else data
        try:
            report = summarize(events)
        except ValueError as exc:
            if not str(exc).startswith("No CUDA kernel events"):
                raise
            ignored.append(str(path))
            continue
        reports.append({"file": str(path), **report})
    if len(reports) != 1:
        raise ValueError(f"Expected one worker CUDA trace, found {len(reports)}")
    return {"worker": reports[0], "ignored_cpu_only_traces": ignored}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("traces", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.write_text(json.dumps(analyze_directory(args.traces), indent=2) + "\n")
