# SM89 BF16 gated projection validation

Frozen experiment evidence for the vLLM opt-in BF16 gated projection change. GPU tests and performance/model evaluations used base b2a9480dc7aa2e8e6aacd09df1a375c34c55f5b5 plus the six files in candidate-source-final.json. This is not a new GPU run on a later rebased head.

See REPRODUCE.md, analysis-final.json, validation/, and the exact source snapshot. The serving comparison uses a drained common-engine control and records real kernel eligibility. No model weights, private source text, or full model response texts are included. The timing input derives from public Apache-2.0 vLLM source; attribution is in prompt-provenance.json and NOTICE-inputs.txt.
