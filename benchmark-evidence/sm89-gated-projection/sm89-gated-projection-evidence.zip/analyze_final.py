"""Audit final serving evidence, using every timed pair and scored question."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import random
import statistics


def paired(rows):
    groups = {}
    for row in rows:
        group = groups.setdefault(row["label"], {})
        assert row["mode"] not in group, "Duplicate mode in a timed pair"
        group[row["mode"]] = row
    assert groups and all(set(g) == {"original", "virtual"} for g in groups.values())
    samples = [
        {
            "label": label,
            "native_s": g["original"]["ttft_s"],
            "candidate_s": g["virtual"]["ttft_s"],
            "saved_ms": (g["original"]["ttft_s"] - g["virtual"]["ttft_s"]) * 1000,
        }
        for label, g in groups.items()
    ]
    values = [s["saved_ms"] for s in samples]
    rng = random.Random(20261103)
    boot = sorted(
        sum(rng.choices(values, k=len(values))) / len(values) for _ in range(5000)
    )
    native = statistics.median(s["native_s"] for s in samples)
    candidate = statistics.median(s["candidate_s"] for s in samples)
    return {
        "pairs": samples,
        "n": len(samples),
        "native_median_ms": native * 1000,
        "candidate_median_ms": candidate * 1000,
        "median_reduction_pct": 100 * (1 - candidate / native),
        "paired_mean_saved_ms": statistics.mean(values),
        "paired_mean_saved_ms_ci95": [boot[124], boot[4874]],
    }


def records(path):
    rows = [json.loads(line) for line in path.read_text().splitlines() if line]
    result = {r["index"]: r for r in rows}
    assert len(rows) == len(result), "Duplicate question index"
    for row in rows:
        choice = row["response"]["choices"][0]
        usage = row["response"]["usage"]
        assert isinstance(choice["prompt_token_ids"], list)
        assert len(choice["prompt_token_ids"]) == usage["prompt_tokens"]
        assert len(choice["token_ids"]) == usage["completion_tokens"]
        assert usage["prompt_tokens_details"]["cached_tokens"] == 0
    return result


def analyze(root, source_lock):
    run = json.loads((root / "run.json").read_text())
    assert run["status"] == "complete"
    config = run["effective_vllm_config"]
    assert config["compilation_config"]["mode"] == 0
    assert config["compilation_config"]["cudagraph_mode"] == [2, 1]
    assert config["scheduler_config"]["max_num_batched_tokens"] == 2048
    assert config["cache_config"]["gpu_memory_utilization"] == 0.85
    assert run["preparation"]["enabled_layers"] == 32
    assert run["preparation"]["persistent_weight_copy_bytes"] == 0
    for name, sha in run["preparation"]["installed_sources"].items():
        assert sha == source_lock[name]["sha256"], name
    for row in run["timings"]:
        assert row["usage"]["prompt_tokens_details"]["cached_tokens"] == 0

    primary = paired([r for r in run["timings"] if r["label"].startswith("primary_")])
    short = {
        str(n): paired(
            [r for r in run["timings"] if r["label"].startswith(f"short_{n}_pair_")]
        )
        for n in [128, 528]
    }
    assert primary["n"] == 12
    assert all(value["n"] == 100 for value in short.values())
    data = {
        name: records(root / f"{name}.jsonl")
        for name in ["native", "candidate", "native_repeat"]
    }
    assert set(data["native"]) == set(data["candidate"]) == set(range(1319))
    differences = []
    outcomes = Counter()
    for i in range(1319):
        left, right = data["native"][i], data["candidate"][i]
        for key in ["label", "prompt_text_sha256", "prompt_token_sha256"]:
            assert left[key] == right[key], (i, key)
        a, b = (
            left["prediction"] == left["label"],
            right["prediction"] == right["label"],
        )
        differences.append(int(b) - int(a))
        outcomes[(a, b)] += 1
    rng = random.Random(20261103)
    boot = sorted(sum(rng.choices(differences, k=1319)) / 1319 for _ in range(5000))
    scores = {
        name: sum(r["prediction"] == r["label"] for r in rows.values())
        for name, rows in data.items()
    }
    calls = run["evaluations"]["candidate"]["dispatch"]["calls"]
    processed = sum(
        int(k.split(":")[1]) * count
        for k, count in calls.items()
        if k.startswith("candidate:")
    )
    prompt_tokens = sum(
        r["response"]["usage"]["prompt_tokens"] for r in data["candidate"].values()
    )
    generated_tokens = sum(
        r["response"]["usage"]["completion_tokens"] for r in data["candidate"].values()
    )
    primary_candidate = [
        r
        for r in run["timings"]
        if r["mode"] == "virtual" and r["label"].startswith("primary_")
    ]
    assert all(
        r["dispatch"]["calls"].get("candidate:1584") == 10 for r in primary_candidate
    )
    no_empty = all(e["empty"] == 0 for e in run["evaluations"].values())
    gates = {
        "primary_at_least_2pct": primary["median_reduction_pct"] >= 2,
        "short_median_regression_at_most_2pct": all(
            v["median_reduction_pct"] >= -2 for v in short.values()
        ),
        "native_score_at_least_077": scores["native"] / 1319 >= 0.77,
        "candidate_score_at_least_077": scores["candidate"] / 1319 >= 0.77,
        "paired_accuracy_delta_at_least_minus_1pp": sum(differences) / 1319 >= -0.01,
        "paired_ci_lower_at_least_minus_1pp": boot[124] >= -0.01,
        "candidate_row_proxy_at_least_25pct": processed / prompt_tokens >= 0.25,
        "no_empty_completions": no_empty,
    }
    peak = {
        mode: statistics.median(
            r["dispatch"]["peak_allocated_bytes"]
            for r in run["timings"]
            if r["mode"] == mode and r["label"].startswith("primary_")
        )
        for mode in ["original", "virtual"]
    }
    return {
        "status": "audited",
        "primary": primary,
        "short": short,
        "peak_allocated_bytes": peak,
        "quality": {
            "n": 1319,
            "native_correct": scores["native"],
            "candidate_correct": scores["candidate"],
            "native_accuracy": scores["native"] / 1319,
            "candidate_accuracy": scores["candidate"] / 1319,
            "paired_difference": sum(differences) / 1319,
            "paired_bootstrap_ci95": [boot[124], boot[4874]],
            "outcomes": {str(k): v for k, v in outcomes.items()},
            "native_repeat_questions": len(data["native_repeat"]),
            "native_repeat_outcome_disagreements": sum(
                (r["prediction"] == r["label"])
                != (data["native"][i]["prediction"] == r["label"])
                for i, r in data["native_repeat"].items()
            ),
            "candidate_processed_rows": processed,
            "total_prompt_tokens": prompt_tokens,
            "total_generated_tokens": generated_tokens,
            "row_to_prompt_ratio": processed / prompt_tokens,
            "conservative_prefill_fraction": max(
                0, (processed - generated_tokens) / prompt_tokens
            ),
            "coverage_note": "Counts observe one representative MLP layer and include mixed decode rows. Ratios are not a per-request hit rate; the lower estimate subtracts all generated tokens.",
            "uncertainty_note": "Paired question bootstrap, 5000 replicates, seed 20261103, question-index order. Conditional on this benchmark and observed schedules, not a universal quality guarantee.",
        },
        "gates": gates,
        "all_gates_pass": all(gates.values()),
        "source_verified": run["preparation"]["installed_sources"],
        "restored_model": run["restored"],
        "server_exit_code": run["owned_server_exit_code"],
        "run_sha256": hashlib.sha256((root / "run.json").read_bytes()).hexdigest(),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--source-lock", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = analyze(args.root, json.loads(args.source_lock.read_text()))
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(
        json.dumps(
            {"all_gates_pass": result["all_gates_pass"], "gates": result["gates"]}
        )
    )


if __name__ == "__main__":
    main()
