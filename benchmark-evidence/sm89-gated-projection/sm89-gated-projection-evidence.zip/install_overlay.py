"""Apply or restore this Python-only candidate over the pinned official wheel."""

import argparse
import hashlib
from importlib import metadata
import json
from pathlib import Path
import shutil
import subprocess

FILES = (
    "vllm/kernels/triton/gated_linear_silu.py",
    "vllm/model_executor/layers/fusion/gated_linear_silu.py",
    "vllm/model_executor/models/qwen2_moe.py",
)
BASE_MODEL_SHA = "efd3c5a3ac286c48bf9a1ed14574a6d5a30c61557d387036148452ca318a9fdb"
VERSION = "0.33.0rc1.dev544+gb2a9480dc"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--backup", type=Path, required=True)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--apply", action="store_true")
    action.add_argument("--restore", action="store_true")
    args = parser.parse_args()
    assert not subprocess.check_output(
        ["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"], text=True
    ).strip(), "Stop GPU users of this environment before changing its files"
    distribution = metadata.distribution("vllm")
    assert distribution.version == VERSION
    if args.apply:
        if args.source is None or args.manifest is None:
            parser.error("--apply requires --source and --manifest")
        manifest = json.loads(args.manifest.read_text())
        entries = {}
        # Validate every file before making the first change.
        for name in FILES:
            source, target = args.source / name, Path(distribution.locate_file(name))
            assert sha(source) == manifest[name]["sha256"], name
            if name.endswith("models/qwen2_moe.py"):
                assert target.exists() and sha(target) == BASE_MODEL_SHA
            else:
                assert not target.exists(), f"Unexpected existing file: {target}"
            entries[name] = {
                "installed": str(target),
                "original_exists": target.exists(),
                "original_sha256": sha(target) if target.exists() else None,
                "candidate_sha256": sha(source),
            }
        args.backup.mkdir(parents=True, exist_ok=False)
        for name, entry in entries.items():
            if entry["original_exists"]:
                saved = args.backup / name
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(entry["installed"], saved)
        state = {"version": VERSION, "status": "backed_up", "files": entries}
        journal = args.backup / "overlay.json"
        journal.write_text(json.dumps(state, indent=2) + "\n")
        for name, entry in entries.items():
            target = Path(entry["installed"])
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(args.source / name, target)
            assert sha(target) == entry["candidate_sha256"]
        state["status"] = "applied"
        journal.write_text(json.dumps(state, indent=2) + "\n")
    else:
        journal = args.backup / "overlay.json"
        state = json.loads(journal.read_text())
        assert state["status"] == "applied"
        for name, entry in state["files"].items():
            assert sha(Path(entry["installed"])) == entry["candidate_sha256"], name
            if entry["original_exists"]:
                assert sha(args.backup / name) == entry["original_sha256"], name
        for name, entry in state["files"].items():
            target = Path(entry["installed"])
            if entry["original_exists"]:
                shutil.copy2(args.backup / name, target)
                assert sha(target) == entry["original_sha256"]
            else:
                target.unlink()
                cache = target.parent / "__pycache__"
                if cache.exists():
                    for pyc in cache.glob(target.stem + ".*.pyc"):
                        pyc.unlink()
        state["status"] = "restored"
        journal.write_text(json.dumps(state, indent=2) + "\n")
    print(json.dumps({"status": state["status"], "journal": str(journal)}))


if __name__ == "__main__":
    main()
