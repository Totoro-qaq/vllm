# Reproduction and evidence boundaries

The patch was tested over the official `b2a9480dc7aa2e8e6aacd09df1a375c34c55f5b5` wheel, with Torch 2.14.0+cu130 and Triton 3.8.0. All final source hashes are in `candidate-source-final.json`. Model files must match `kit/model-lock.json`; use ModelScope to obtain the checkpoint and verify those hashes. Model weights are not bundled.

The patch also applies cleanly to checked upstream head `8b30f56b1a5238617d08ebe678472475e199f8f3`. That is an application check, not a claim of a complete GPU run on the latter framework head.

## Repository patch and kernel checks

On a suitable checkout, apply `candidate.patch`. Follow the repository's documented environment setup; this change has no C/C++ modifications and can reuse matching precompiled extensions.

```bash
git apply /path/to/candidate.patch
VLLM_USE_PRECOMPILED=1 uv pip install -e . --no-deps
.venv/bin/python -m pytest tests/kernels/test_gated_linear_silu.py -q
.venv/bin/python benchmarks/kernels/benchmark_gated_linear_silu.py \
  --tokens 16 528 768 1056 1584 2048 4096 --json gated-projection.json
```

The recorded GPU test used the same proposed file standalone against the patched official wheel, with plugin autoload disabled:

```bash
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 OMP_NUM_THREADS=1 \
  /root/autodl-tmp/prefill-profile-20261103/.venv/bin/python -m pytest \
  /root/autodl-tmp/mlp-confirmation-20261103/candidate-source-final/tests/kernels/test_gated_linear_silu.py -q
```

Result: 23 passed. This is not the complete repository test suite or upstream CI. The proposed test is self-contained and uses real tensors, real vLLM configuration/linear constructors and a real single-rank process group.

## Exact serving experiment

The frozen runner checks the official wheel's version and a **clean baseline checkout**. Keep that baseline checkout separate from a dirty/editable candidate checkout. For exact reproduction, the supplied `install_overlay.py` applies only the three runtime Python files to the matching official wheel and keeps a verified rollback journal.

Run these commands from the extracted evidence bundle root. The paths below are the original prepared-host paths; set `LAB_ROOT` to the extracted bundle and `PROFILE_ROOT` to your matching prepared runtime when reproducing elsewhere.

```bash
export PROFILE_ROOT=/root/autodl-tmp/prefill-profile-20261103
export LAB_ROOT=/root/autodl-tmp/mlp-confirmation-20261103
export CUDA_HOME=/usr/local/cuda
export PATH="$PROFILE_ROOT/.venv/bin:$CUDA_HOME/bin:$PATH"
export PYTHONPATH="$LAB_ROOT/kit"

"$PROFILE_ROOT/.venv/bin/python" install_overlay.py --apply \
  --source "$LAB_ROOT/candidate-source-final" \
  --manifest "$LAB_ROOT/candidate-source-final.json" \
  --backup "$LAB_ROOT/reproduction-backup"

"$PROFILE_ROOT/.venv/bin/python" "$LAB_ROOT/kit/eval_final.py" \
  --repo "$PROFILE_ROOT/source-b2" --model-dir "$PROFILE_ROOT/model" \
  --capture . --data "$LAB_ROOT/eval-data" \
  --output "$LAB_ROOT/final-reproduction" --execute

"$PROFILE_ROOT/.venv/bin/python" "$LAB_ROOT/kit/sync_smoke.py" \
  --repo "$PROFILE_ROOT/source-b2" --model-dir "$PROFILE_ROOT/model" \
  --capture . --data "$LAB_ROOT/eval-data" \
  --output "$LAB_ROOT/sync-reproduction" --execute

"$PROFILE_ROOT/.venv/bin/python" install_overlay.py --restore \
  --backup "$LAB_ROOT/reproduction-backup"
```

`--capture` is retained for runner compatibility; the final integrated worker does not read activation snapshots. Actual replay of the earlier micro-experiment needs those snapshots and the model weights; final serving reproduction does not.

The exact final benchmark keeps compilation mode 0 explicitly and uses `custom_ops=["all","+gated_linear_silu"]`; graphs remain FULL_AND_PIECEWISE. The timing control toggles the actual operation child while requests are drained, without replacing forward methods. A read-only first-layer hook records eligible steps. This common-engine A/B holds graph and KV allocation constant. The standard CLI opt-in and opt-out can also be used for independent service comparisons, but those are not the reported paired samples.

The runner executes 12 paired long requests and 100 paired requests per short length. It stops before full evaluation if integrated TTFT improvement is below 2%. Otherwise it runs the full frozen GSM8K set in both modes plus a fixed 64-question native repeat. The sync script sets and verifies `VLLM_GPU_SYNC_CHECK=error`; its diagnostic timing is not used for speed claims.

Dataset URLs and SHA256 are in `eval-data/manifest.json`. The data are the vLLM public CI GSM8K assets. Fetch train/test JSONL from those exact URLs and verify the hashes if using the smaller review bundle instead of the full local archive.

The helper can run locally before renting GPU time:

```bash
.venv/bin/python prepare_eval_data.py --data-dir eval-data
```

The 16K timing input is a token-prefix composition of public Apache-2.0 vLLM code, not private user data or a natural QA benchmark. `prompt-provenance.json` records the source URLs and construction. The frozen token IDs and hash are authoritative; do not retokenize or replace the input when comparing to the recorded numbers.

## Offline audit

```bash
.venv/bin/python analyze_final.py --root remote-evidence/final-v2 \
  --source-lock candidate-source-final.json --output analysis-reproduced.json
```

The analysis verifies source hashes, configuration, pair counts, zero cache hits, prompt identity and all question indices before computing results. It rejects duplicate timed modes and duplicate questions. The archive manifest covers 141 remote files. Its SHA256 is `fffd403cb689dea6eb076a7ee74010d339fdcaaf4767b01c9be5a2d2415b69ea`.

The full raw archive remains local. The smaller review bundle includes the patch, source/protocols, aggregate/paired evidence, per-question numeric outcomes and reproduction code. No model weights are included in either. Existing remote GPU services have been stopped and the original installed vLLM files restored; the instance itself was not powered off.
